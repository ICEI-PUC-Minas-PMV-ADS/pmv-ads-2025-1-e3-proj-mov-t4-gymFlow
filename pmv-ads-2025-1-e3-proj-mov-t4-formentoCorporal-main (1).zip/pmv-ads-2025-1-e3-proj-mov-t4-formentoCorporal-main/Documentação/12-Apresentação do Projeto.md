## GymFlow

Plataforma interativa de criação de treinos

## Conjunto de Slides (Estrutura)

[Slides.pdf](https://github.com/user-attachments/files/19153850/Slides.pdf)

https://github.com/user-attachments/assets/ed39432e-e7dd-4cd9-b99b-bb496219d507
