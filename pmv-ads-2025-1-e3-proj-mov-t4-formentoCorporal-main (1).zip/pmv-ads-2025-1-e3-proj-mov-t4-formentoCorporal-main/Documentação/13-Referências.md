
# Referências

NASCIMENTO, Samuel Alves Ferreira. Fatores motivacionais para prática de exercício físico em academias. 2019. Trabalho de Conclusão de Curso (Bacharelado em Educação Física) – Centro Universitário de Brasília, Brasília, 2019. Disponível em: https://repositorio.uniceub.br/jspui/bitstream/prefix/13848/1/21553999.pdf. Acesso em: 9 mar. 2025. 
