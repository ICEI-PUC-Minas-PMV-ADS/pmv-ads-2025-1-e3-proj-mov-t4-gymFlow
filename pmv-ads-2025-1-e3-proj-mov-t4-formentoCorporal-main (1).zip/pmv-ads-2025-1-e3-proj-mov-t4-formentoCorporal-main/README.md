# GymFlow

`CURSO`  
Análise e desenvolvimento de sistemas

`DISCIPLINA`  
Desenvolvimento de uma aplicação interativa

`SEMESTRE`  
2°

Este projeto tem como objetivo desenvolver um sistema de back-end voltado para um aplicativo de calistenia, HIIT (High-Intensity Interval Training ou Treinamento Intervalado de Alta Intensidade) e academia a fim de que o usuário consiga registrar seus treinos e moldar suas práticas de maneira que ele mesmo possa adicionar ou remover seus exercícios.

## Integrantes

Gabriel Rodrigues  
Jefferson L. Silva  
Kauã Silva  
William Viana
Caio Rosa

## Orientador

Carlos Alberto Marques Pietrobon

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.

Não deixe de informar o link onde a aplicação estiver disponível para acesso (por exemplo: https://adota-pet.herokuapp.com/src/index.html).

Se houver usuário de teste, o login e a senha também deverão ser informados aqui (por exemplo: usuário - admin / senha - admin).

O link e o usuário/senha descritos acima são apenas exemplos de como tais informações deverão ser apresentadas.

# Documentação

<ol>
<li><a href="documentação/01-Documentação de Contexto.md"> Documentação de Contexto</a></li>
<li><a href="documentação/02-Especificação do Projeto.md"> Especificação do Projeto</a></li>
<li><a href="documentação/03-Metodologia.md"> Metodologia</a></li>
<li><a href="documentação/04-Projeto de Interface.md"> Projeto de Interface</a></li>
<li><a href="documentação/05-Arquitetura da Solução.md"> Arquitetura da Solução</a></li>
<li><a href="documentação/06-Template Padrão da Aplicação.md"> Template Padrão da Aplicação</a></li>
<li><a href="documentação/07-Programação de Funcionalidades.md"> Programação de Funcionalidades</a></li>
<li><a href="documentação/08-Plano de Testes de Software.md"> Plano de Testes de Software</a></li>
<li><a href="documentação/09-Registro de Testes de Software.md"> Registro de Testes de Software</a></li>
<li><a href="documentação/10-Plano de Testes de Usabilidade.md"> Plano de Testes de Usabilidade</a></li>
<li><a href="documentação/11-Registro de Testes de Usabilidade.md"> Registro de Testes de Usabilidade</a></li>
<li><a href="documentação/12-Apresentação do Projeto.md"> Apresentação do Projeto</a></li>
<li><a href="documentação/13-Referências.md"> Referências</a></li>
</ol>

# Código

<li><a href="src/README.md"> Código Fonte</a></li>

# Apresentação

<li><a href="presentation/README.md"> Apresentação da solução</a></li>
